package com.dipendenti.dipendenti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DipendentiApplicationTests {

	@Test
	void contextLoads() {
	}

}
